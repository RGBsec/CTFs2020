package androidx.lifecycle;

import androidx.lifecycle.Lifecycle.Event;

public interface GeneratedAdapter {
    void callMethods(LifecycleOwner lifecycleOwner, Event event, boolean z, MethodCallsLogger methodCallsLogger);
}
