package androidx.lifecycle;

/* renamed from: androidx.lifecycle.R */
public final class C0221R {
    private C0221R() {
    }
}
