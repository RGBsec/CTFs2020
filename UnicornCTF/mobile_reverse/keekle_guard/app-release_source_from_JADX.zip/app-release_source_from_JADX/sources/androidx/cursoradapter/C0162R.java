package androidx.cursoradapter;

/* renamed from: androidx.cursoradapter.R */
public final class C0162R {
    private C0162R() {
    }
}
