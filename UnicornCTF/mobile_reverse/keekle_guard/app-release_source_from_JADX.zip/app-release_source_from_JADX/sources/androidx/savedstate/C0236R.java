package androidx.savedstate;

/* renamed from: androidx.savedstate.R */
public final class C0236R {
    private C0236R() {
    }
}
