package androidx.versionedparcelable;

/* renamed from: androidx.versionedparcelable.R */
public final class C0249R {
    private C0249R() {
    }
}
