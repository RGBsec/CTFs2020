package androidx.interpolator;

/* renamed from: androidx.interpolator.R */
public final class C0213R {
    private C0213R() {
    }
}
